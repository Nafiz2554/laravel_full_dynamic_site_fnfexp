
<?php $__env->startSection('main-container'); ?>
    <!-- page-title -->
    <div class="ttm-page-title-row">
        <div class="ttm-page-title-row-bg-layer ttm-bg-layer"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title-box ttm-textcolor-white">
                        <div class="page-title-heading">
                            <h1 class="title">Our management Team</h1>
                        </div><!-- /.page-title-captions -->
                        <div class="breadcrumb-wrapper">
                            <span>
                                <a title="Homepage" href="index-3.html"><i class="ti ti-home"></i></a>
                            </span>
                            <span class="ttm-bread-sep">&nbsp; / &nbsp;</span>
                            <span><span>Details</span></span>
                        </div>
                    </div>
                </div><!-- /.col-md-12 -->
            </div><!-- /.row -->
        </div><!-- /.container -->
    </div><!-- page-title end-->

    <div class="container">
        <div class="row">
            <?php if($aboutus): ?>
                <?php $__currentLoopData = $aboutus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-12 col-lg-6">
                        <div class="card">
                            <div class="card-body">
                                <img src="<?php echo e(asset('/storage/' . $aboutus->image)); ?>" class="card-img-top" alt="...">
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body text-center">
                                <p style="font-family:cursive;font-size:larger;color:#3ea30a;">Our Management</p>
                                <hr>
                                <p style="font-weight:bold;opacity:80%;">We Serve You!</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-lg-6" style="margin-top: 6rem;">
                        <div class="card">
                            <div class="card-body">
                                <ul class="list-group">
                                    <li class="list-group-item text-center"><b>Name: <?php echo e($aboutus->name); ?></b></li>
                                    <li class="list-group-item  text-center"><b>Designation:</b> <?php echo e($aboutus->designation); ?></li>
                                    <li class="list-group-item"><?php echo e($aboutus->desc); ?></li>

                                </ul>
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\fnfexpress\fnfexp\resources\views/frontend/aboutus_details.blade.php ENDPATH**/ ?>