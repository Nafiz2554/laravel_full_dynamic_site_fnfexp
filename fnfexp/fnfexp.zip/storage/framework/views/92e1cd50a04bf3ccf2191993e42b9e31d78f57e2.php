
<?php $__env->startSection('main-container'); ?>
    <div class="site-main">

        <section class="ttm-row">
            <div class="container">
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
                        <!-- section title -->
                        <div class="section-title with-desc title-style-center_text mb-55 clearfix">
                            <div class="title-header">
                                <h2 class="title">Do you have Questions?</h2>
                            </div>
                            <div class="title-desc"><a href="<?php echo e(url('/contact')); ?>">Click Here To Ask</a></div>
                        </div><!-- section title end -->
                    </div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <!-- single-img -->
                        <div class="single-img mb-35">
                            <img class="img-fluid" src="<?php echo e(asset('assets/images/single-image-seven.jpg')); ?>" alt="">
                            <div class="ttm-video-btn text-center">
                                <a class="ttm-play-btn ttm_prettyphoto" href="https://youtu.be/MdLVzXf7v5E">
                                    <span class="ttm-btn-play"><i class="fa fa-play"></i></span>
                                </a>
                            </div>
                        </div><!-- single-img end -->
                    </div>
                    <div class="col-lg-6">
                        <!-- acadion -->
                        <div class="accordion">
                            <!-- toggle -->
                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="toggle ttm-style-classic ttm-toggle-title-border">
                                    <div class="toggle-title"><a data-toggle="collapse" data-parent="#accordion"
                                            href="#collapseOne"><?php echo e($faq->ques); ?></a></div>
                                    <div class="toggle-content">
                                        <p><?php echo e($faq->ans); ?></p>
                                    </div>
                                </div><!-- toggle end -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </div><!-- acadion end-->
                    </div>
                </div>

            </div>
        </section>



    </div>
    <!--site-main end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\fnfexpress\fnfexp\resources\views/frontend/faq.blade.php ENDPATH**/ ?>