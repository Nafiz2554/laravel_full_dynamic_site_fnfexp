
<?php $__env->startSection('admin_content'); ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>


<div class="row-fluid sortable">
<div class="box span12">
    <div class="box-header" data-original-title>
        <p class="alert-success">
            <?php
            $message= Session()->get('message');
            if($message){
                echo $message;
                Session()->put('message',null);
            }
            ?>
        </p>
        <h2><i class="halflings-icon edit"></i><span class="break"></span>Edit service Plan</h2>

    </div>

    <div class="box-content">
        <form class="form-horizontal" action="<?php echo e(url('/plan-update/'.$plan->id)); ?>" method="post" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>
             
            <fieldset>
                <div class="control-group">
                    <label class="control-label" for="date01">Edit Plan's Title</label>
                    <div class="controls">
                        <input type="text" class="input-xlarge" name="title" value="<?php echo e($plan->title); ?>">
                    </div>
                </div>


                <div class="control-group hidden-phone">
                    <label class="control-label" for="textarea2">Edit Subtitle</label>
                    <div class="controls">
                        <textarea class="cleditor" name="subtitle" rows="3" required><?php echo e($plan->subtitle); ?></textarea>
                    </div>

                </div>

                <div class="control-group">
                    <label class="control-label" for="date01">Edit Price</label>
                    <div class="controls">
                        <input type="text" class="input-xlarge" name="price" value="<?php echo e($plan->price); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="date01">Edit Unit</label>
                    <div class="controls">
                        <input type="text" class="input-xlarge" name="unit" value="<?php echo e($plan->unit); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="date01">Edit Input Information</label>
                    <div class="controls">
                        <input type="text" class="input-xlarge" name="input1" value="<?php echo e($plan->input1); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="date01">Edit Input Information</label>
                    <div class="controls">
                        <input type="text" class="input-xlarge" name="input2" value="<?php echo e($plan->input2); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="date01">Edit Input Information</label>
                    <div class="controls">
                        <input type="text" class="input-xlarge" name="input3" value="<?php echo e($plan->input3); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="date01">Edit Input Information</label>
                    <div class="controls">
                        <input type="text" class="input-xlarge" name="input4" value="<?php echo e($plan->input4); ?>">
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="date01">Edit Contact Number</label>
                    <div class="controls">
                        <input type="text" class="input-xlarge" name="mobile_no" value="<?php echo e($plan->mobile_no); ?>">
                    </div>
                </div>

                 


                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Update Plan</button>
                </div>
            </fieldset>
        </form>

    </div>
</div>
<!--/span-->
</div>
<!--/row-->
</div>
<!--/row-->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\fnfexpress\fnfexp\resources\views/admin/plan/edit.blade.php ENDPATH**/ ?>