
<?php $__env->startSection('main-container'); ?>
<div class="container">
     

    <div class="container">
        <h1>result</h1>

        <?php echo e($parcel); ?>

    </div>



    

    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\fnfexpress\fnfexp\resources\views/frontend/parcel_search.blade.php ENDPATH**/ ?>